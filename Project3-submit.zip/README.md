## Compile and run

-   Start 7 servers specified machines (commentted in Server.java)
    - On each machine run java Process s1 i (replace 1 with 2,3,4,5,6,7)
-   After 7 servers are iniliazed, start the clients by running 
    - On each machine run java Process c1 (replace 1 with 2,3,4,5)

## Project structure

-   source folder: src
-   test: manually
